---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

As a **[developer, moderator, logged-in-user, public-user]**

I want to **be able to visit the /login page**

So that **I can login to my account**

Metric: **Within 1 button click of visiting the home page**
