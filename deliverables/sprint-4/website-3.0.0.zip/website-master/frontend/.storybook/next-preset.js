const path = require("path");

module.exports = {
  webpackFinal: async (baseConfig, options) => {
    // Modify or replace config. Mutating the original reference object can cause unexpected bugs.
    const { module = {} } = baseConfig;

    const newConfig = {
      ...baseConfig,
      module: {
        ...module,
        rules: [...(module.rules || [])]
      }
    };

    // TypeScript with Next.js
    newConfig.module.rules.push({
      test: /\.(ts|tsx)$/,
      include: [
        path.resolve(__dirname, "../components"),
        path.resolve(__dirname, "../stories")
      ],
      use: [
        {
          loader: "babel-loader",
          options: {
            presets: ["next/babel"]
          }
        },
        require.resolve("react-docgen-typescript-loader")
      ]
    });
    newConfig.resolve.extensions.push(".ts", ".tsx");

    return newConfig;
  }
};
