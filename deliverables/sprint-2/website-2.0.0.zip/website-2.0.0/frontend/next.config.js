module.exports = {
  target: "serverless"
};
