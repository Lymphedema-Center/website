<p align="center">
  <img src=".github/docs/lymphedema-center.png"/>
</p>
<p align="center">
  <a href="https://lymphedema-center.com">Website</a> |
  <a href="https://github.com/Lymphedema-Center/website/wiki">Wiki</a>
</p>

<h3 align="center">
  Helping people manage Lymphedema.
</h3>

<p align="center">
  Providing a symptoms guide, preventative measures guide, community forums, and personal treatment log.
</p>

<p align="center">
  <a href="https://github.com/Lymphedema-Center/website/blob/master/LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License" />
  </a>
  <a href="https://cypress.io">
    <img src="https://img.shields.io/badge/cypress.io-tests-green.svg?style=flat-square" alt="Cypress.io Tests" />
  </a>
</p>
