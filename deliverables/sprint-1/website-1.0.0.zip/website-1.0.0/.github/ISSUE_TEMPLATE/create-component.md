---
name: Create component
about: Describe the component to be created.
title: ''
labels: enhancement
assignees: ''

---

- [ ] Props
    - [ ] prop - description of the prop
- [ ] Storybook documentation
- [ ] Cypress unit test

### Notes
Here you can record the notes that you need to note in this here notes section.
